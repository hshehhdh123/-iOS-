import SwiftUI

struct ConfirmationView: View {
    let selectedCount: Int
    let onConfirm: () -> Void
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 18) {
            Image(systemName: "sparkles.rectangle.stack")
                .font(.system(size: 42))
                .foregroundStyle(.orange)
            Text("确认美化")
                .font(.title2.bold())
            Text("已选择 \(selectedCount) 项。此功能目前用于图鉴选择与流程演示，不会修改游戏服务器或游戏内资源。")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.65))
                .multilineTextAlignment(.center)
            Button(action: onConfirm) {
                Text("确认美化")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.red.opacity(0.8), in: RoundedRectangle(cornerRadius: 15))
            }
            Button("返回修改") { dismiss() }
                .foregroundStyle(.white.opacity(0.65))
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.09, green: 0.035, blue: 0.035))
        .preferredColorScheme(.dark)
    }
}
