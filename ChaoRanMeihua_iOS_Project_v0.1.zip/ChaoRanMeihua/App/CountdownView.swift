import SwiftUI

struct CountdownView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var remaining = 3
    @State private var finished = false
    @State private var timer: Timer?

    var body: some View {
        VStack(spacing: 22) {
            Spacer()
            Image(systemName: finished ? "checkmark.circle" : "hourglass")
                .font(.system(size: 58, weight: .light))
                .foregroundStyle(.orange)
            Text(finished ? "准备完成" : "正在准备")
                .font(.largeTitle.bold())
            Text(finished ? "请手动打开《超自然行动组》。当前尚未配置可验证的游戏跳转链接。" : "\(remaining)")
                .font(finished ? .subheadline : .system(size: 72, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.78))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 28)
            Spacer()
            Button {
                timer?.invalidate()
                dismiss()
            } label: {
                Text("完成")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(.white.opacity(0.1), in: RoundedRectangle(cornerRadius: 15))
            }
            .padding(.horizontal, 24)
            .padding(.bottom, 20)
        }
        .background(Color(red: 0.08, green: 0.025, blue: 0.025).ignoresSafeArea())
        .foregroundStyle(.white)
        .onAppear(perform: startCountdown)
        .onDisappear { timer?.invalidate() }
    }

    private func startCountdown() {
        timer?.invalidate()
        remaining = 3
        finished = false
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { t in
            if remaining > 1 {
                remaining -= 1
            } else {
                t.invalidate()
                finished = true
            }
        }
    }
}
