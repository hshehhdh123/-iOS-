import SwiftUI

enum CatalogCategory: String, CaseIterable, Identifiable {
    case skins, characters, lobbies, vehicles
    var id: String { rawValue }
    var title: String {
        switch self {
        case .skins: return "皮肤"
        case .characters: return "角色"
        case .lobbies: return "大厅"
        case .vehicles: return "车辆"
        }
    }
    var symbol: String {
        switch self {
        case .skins: return "tshirt"
        case .characters: return "person"
        case .lobbies: return "house"
        case .vehicles: return "car"
        }
    }
}

struct CatalogItem: Identifiable {
    let id: String
    let name: String
    let category: CatalogCategory
    let note: String

    // 保持为空，直到加入已核实的官方/用户提供素材。
    static let samples: [CatalogItem] = []
}
