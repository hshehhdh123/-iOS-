import SwiftUI

struct ContentView: View {
    @State private var selectedCategory: CatalogCategory = .skins
    @State private var searchText = ""
    @State private var selectedIDs: Set<String> = []
    @State private var showingConfirmation = false
    @State private var showingCountdown = false

    private var visibleItems: [CatalogItem] {
        CatalogItem.samples.filter {
            $0.category == selectedCategory &&
            (searchText.isEmpty || $0.name.localizedCaseInsensitiveContains(searchText))
        }
    }

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.10, green: 0.035, blue: 0.035), .black],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            ).ignoresSafeArea()

            VStack(spacing: 16) {
                header
                searchBar
                categoryPicker

                HStack {
                    Text(selectedCategory.title)
                        .font(.title3.bold())
                    Spacer()
                    Text("\(selectedIDs.count) 项已选择")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.58))
                }
                .padding(.horizontal, 20)

                if visibleItems.isEmpty {
                    emptyState
                } else {
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(visibleItems) { item in
                                CatalogRow(
                                    item: item,
                                    isSelected: selectedIDs.contains(item.id)
                                ) {
                                    toggle(item)
                                }
                            }
                        }
                        .padding(.horizontal, 16)
                        .padding(.bottom, 100)
                    }
                }
                Spacer(minLength: 0)
            }
            .padding(.top, 12)

            VStack {
                Spacer()
                Button {
                    showingConfirmation = true
                } label: {
                    HStack {
                        Image(systemName: "sparkles")
                        Text("开始美化")
                        Spacer()
                        Text("\(selectedIDs.count)")
                            .font(.caption.bold())
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(.black.opacity(0.2), in: Capsule())
                    }
                    .font(.headline)
                    .foregroundStyle(.white)
                    .padding(.horizontal, 20)
                    .frame(height: 56)
                    .background(
                        LinearGradient(colors: [Color(red: 0.72, green: 0.16, blue: 0.10), Color(red: 0.42, green: 0.06, blue: 0.06)], startPoint: .leading, endPoint: .trailing),
                        in: RoundedRectangle(cornerRadius: 18)
                    )
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(.orange.opacity(0.35), lineWidth: 1))
                }
                .disabled(selectedIDs.isEmpty)
                .opacity(selectedIDs.isEmpty ? 0.45 : 1)
                .padding(.horizontal, 18)
                .padding(.bottom, 12)
            }
        }
        .sheet(isPresented: $showingConfirmation) {
            ConfirmationView(
                selectedCount: selectedIDs.count,
                onConfirm: {
                    showingConfirmation = false
                    showingCountdown = true
                }
            )
            .presentationDetents([.medium])
            .presentationDragIndicator(.visible)
        }
        .fullScreenCover(isPresented: $showingCountdown) {
            CountdownView()
        }
    }

    private var header: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(LinearGradient(colors: [.orange.opacity(0.9), .red.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "sparkles")
                    .font(.system(size: 23, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 48, height: 48)

            VStack(alignment: .leading, spacing: 3) {
                Text("超自然美化")
                    .font(.title2.bold())
                Text("装扮图鉴 · 个人收藏")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.58))
            }
            Spacer()
            Image(systemName: "slider.horizontal.3")
                .font(.title3)
                .foregroundStyle(.white.opacity(0.8))
                .padding(12)
                .background(.white.opacity(0.07), in: Circle())
        }
        .padding(.horizontal, 20)
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass").foregroundStyle(.white.opacity(0.5))
            TextField("搜索皮肤或名称", text: $searchText)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .foregroundStyle(.white)
            if !searchText.isEmpty {
                Button { searchText = "" } label: {
                    Image(systemName: "xmark.circle.fill").foregroundStyle(.white.opacity(0.5))
                }
            }
        }
        .padding(14)
        .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 15))
        .overlay(RoundedRectangle(cornerRadius: 15).stroke(.white.opacity(0.08), lineWidth: 1))
        .padding(.horizontal, 18)
    }

    private var categoryPicker: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 9) {
                ForEach(CatalogCategory.allCases) { category in
                    Button {
                        selectedCategory = category
                    } label: {
                        HStack(spacing: 6) {
                            Image(systemName: category.symbol)
                            Text(category.title)
                        }
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(selectedCategory == category ? .white : .white.opacity(0.62))
                        .padding(.horizontal, 15)
                        .padding(.vertical, 10)
                        .background {
                            Capsule().fill(selectedCategory == category ? Color.red.opacity(0.72) : .white.opacity(0.07))
                        }
                        .overlay(Capsule().stroke(selectedCategory == category ? .orange.opacity(0.45) : .white.opacity(0.06), lineWidth: 1))
                    }
                }
            }
            .padding(.horizontal, 18)
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "photo.on.rectangle.angled")
                .font(.system(size: 38))
                .foregroundStyle(.orange.opacity(0.8))
            Text(searchText.isEmpty ? "素材库正在准备中" : "没有找到相关内容")
                .font(.headline)
            Text(searchText.isEmpty ? "这里会展示核实过的游戏素材。当前版本没有用虚构皮肤填充图鉴。" : "试试其他关键词")
                .font(.caption)
                .foregroundStyle(.white.opacity(0.55))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .padding(32)
    }

    private func toggle(_ item: CatalogItem) {
        if selectedIDs.contains(item.id) {
            selectedIDs.remove(item.id)
        } else {
            selectedIDs.insert(item.id)
        }
    }
}
