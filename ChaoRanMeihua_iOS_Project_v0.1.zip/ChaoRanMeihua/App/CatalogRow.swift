import SwiftUI

struct CatalogRow: View {
    let item: CatalogItem
    let isSelected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 14) {
                RoundedRectangle(cornerRadius: 13)
                    .fill(.white.opacity(0.06))
                    .frame(width: 72, height: 82)
                    .overlay {
                        Image(systemName: "person.crop.rectangle")
                            .font(.system(size: 25))
                            .foregroundStyle(.white.opacity(0.3))
                    }
                VStack(alignment: .leading, spacing: 6) {
                    Text(item.name).font(.headline)
                    Text(item.note)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.55))
                }
                Spacer()
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .font(.title2)
                    .foregroundStyle(isSelected ? .orange : .white.opacity(0.35))
            }
            .padding(12)
            .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 17))
            .overlay(RoundedRectangle(cornerRadius: 17).stroke(isSelected ? .orange.opacity(0.55) : .white.opacity(0.06), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}
